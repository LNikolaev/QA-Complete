1. REST Assured

Web Site: http://rest-assured.io/
GitHub Repo: https://github.com/rest-assured/rest-assured
Wikis: https://github.com/rest-assured/rest-assured/wiki

Notes: Show release notes, and 3.0.0 release date

2. JUnit Asserts

Show com.pragmatic.rest -> HelloWorld

3. JUnit Hooks

Show com.pragmatic.rest -> ITeBooks

4. Show RestAssured Basics

Show com.pragmatic.rest -> ITeBooks
Show com.pragmatic.f1 -> SmokeTests

5. DataDriven REST Assured tests with JUnit

Show com.pragmatic.f1 -> DataDrivenTests

6. Show somethng real we know

Show com.pragmatic.rest -> TelerikAPI