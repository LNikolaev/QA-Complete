package automation;

import org.junit.Assert;
import org.junit.Test;

public class OtherTest {

	@Test
	public void other1() {
		System.out.println("Thread name: " + Thread.currentThread().getName());
	}

	@Test
	public void other2() {
		System.out.println("Thread name: " + Thread.currentThread().getName());
	}

	@Test
	public void other3() {
		System.out.println("Thread name: " + Thread.currentThread().getName());
	}

	@Test
	public void other4() {
		System.out.println("Thread name: " + Thread.currentThread().getName());
	}

	@Test
	public void other5() {
		System.out.println("Thread name: " + Thread.currentThread().getName());
	}
}
