package bg.pragmatic.core.pages;

import org.openqa.selenium.WebDriver;

import bg.pragmatic.core.pages.base.ParentPage;

public class AdminCategories extends ParentPage {

	public AdminCategories(WebDriver driver) {
		super(driver);
	}

}
